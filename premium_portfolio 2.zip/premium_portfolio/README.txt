Premium portfolio website

Files:
- index.html
- style.css
- script.js

How to run:
1. Open folder in VS Code
2. Open index.html with Live Server

Update these values:
- WhatsApp number
- Email
- GitHub
- LinkedIn
- CV file name
- Profile image
